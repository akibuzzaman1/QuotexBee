import os
import sys
import platform
import subprocess

try:
    from rich.console import Console
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "rich"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    from rich.console import Console

console = Console()

MAIN_SCRIPT_NAME = os.path.join(os.path.dirname(__file__), "cliQuotexBee.py")
VENV_NAME = "venv"

PIP_LIBRARIES = {
    "rich": "rich",
    "telethon": "telethon",
    "pyfiglet": "pyfiglet",
    "certifi": "certifi",
    "urllib3": "urllib3",
    "websocket-client": "websocket",
    "beautifulsoup4": "bs4",
    "PySocks": "socks"
}

def run_command(command_list: list) -> bool:
    try:
        subprocess.run(
            command_list, check=True, text=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def check_and_get_missing_libs(python_exe: str) -> list:
    missing = []
    with console.status("[spinner]Checking required libraries...", spinner="dots") as status:
        for package, module in PIP_LIBRARIES.items():
            status.update(f"[spinner]Checking for [cyan]{package}[/cyan]...")
            if not run_command([python_exe, "-c", f"import {module}"]):
                missing.append(package)
    return missing

def launch_application(python_exe: str):
    console.clear()
    console.rule("[bold green]Launching Application[/]", style="green")
    try:
        os.execv(python_exe, [python_exe, MAIN_SCRIPT_NAME])
    except Exception as e:
        console.print(f"[bold red]Fatal Error: Could not launch application.[/]\nDetails: {e}")
        sys.exit(1)

def setup_pc_venv(python_to_use: str):
    if not os.path.isdir(VENV_NAME):
        with console.status("[spinner]Creating isolated environment (venv)...", spinner="dots"):
            if not run_command([python_to_use, "-m", "venv", VENV_NAME]):
                console.print("[bold red]❌ Failed to create isolated environment.[/]")
                console.print("   On Debian/Ubuntu, you may need to run: [cyan]sudo apt install python3-venv[/]")
                sys.exit(1)

def install_python_libs(python_exe: str, missing_libs: list):
    with console.status(f"[spinner]Installing {len(missing_libs)} required libraries...", spinner="dots"):
        if not run_command([python_exe, "-m", "pip", "install"] + missing_libs):
            console.print("[bold red]❌ Failed to install Python libraries.[/]")
            sys.exit(1)

def main():
    console.clear()
    
    if not os.path.exists(MAIN_SCRIPT_NAME):
        console.print(f"❌ [bold red]CRITICAL: Main application script '{MAIN_SCRIPT_NAME}' not found.[/]")
        sys.exit(1)

    is_termux = "com.termux" in os.environ.get("PREFIX", "")
    
    if is_termux:
        python_exe = sys.executable
    else:
        setup_pc_venv(sys.executable)
        
        if platform.system() == "Windows":
            python_exe = os.path.join(VENV_NAME, "Scripts", "python.exe")
        else:
            python_exe = os.path.join(VENV_NAME, "bin", "python")

    missing_libs = check_and_get_missing_libs(python_exe)

    if missing_libs:
        console.rule("[bold magenta]One-Time Library Installation[/]", style="magenta")
        install_python_libs(python_exe, missing_libs)
    
    launch_application(python_exe)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n\n[yellow]Operation cancelled by user.[/]")
